
if ( at_home() ){
   expect_equal(1 + 1, 2)
}


